
function initializeIndexCharts(){
    try{
      var myPieChart = new Chart($(".isc").get(0).getContext("2d"),{
        type: 'pie',
        data: data,
        options: {
            legend: {
                display: true,
            },
        }
      });
  }
  catch (e){
    console.log("indiv page" + e)

  }
}
;
